import { Chart } from '@/base-components';
import { colors } from '@/utils';
import PropTypes from 'prop-types';
import { useRecoilValue } from 'recoil';
import { colorScheme as colorSchemeStore } from '@/stores/color-scheme';
import { useMemo } from 'react';
import React from 'react';

function Main(props) {
	const colorScheme = useRecoilValue(colorSchemeStore);

	const data = useMemo(() => {
		return {
			labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
			datasets: [
				{
					label: '# of Votes',
					data: [0, 200, 250, 200, 500, 450, 850, 1050, 950, 1100, 900, 1200],
					borderWidth: 2,
					borderDash: [2, 2],
					borderColor: colorScheme && props.lineColor.length ? props.lineColor : colors.slate['300'](),
					backgroundColor: 'transparent',
					pointBorderColor: 'transparent',
				},
			],
		};
	});

	const options = useMemo(() => {
		return {
			maintainAspectRatio: false,
			plugins: {
				legend: {
					display: false,
				},
			},
			scales: {
				x: {
					ticks: {
						display: false,
					},
					grid: {
						display: false,
						drawBorder: false,
					},
				},
				y: {
					ticks: {
						display: false,
					},
					grid: {
						display: false,
						drawBorder: false,
					},
				},
			},
		};
	});

	return (
		<Chart
			type='line'
			width={props.width}
			height={props.height}
			data={data}
			options={options}
			className={props.className}
		/>
	);
}

Main.propTypes = {
	width: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
	height: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
	lineColor: PropTypes.string,
	className: PropTypes.string,
};

Main.defaultProps = {
	width: 'auto',
	height: 'auto',
	lineColor: '',
	className: '',
};

export default Main;
